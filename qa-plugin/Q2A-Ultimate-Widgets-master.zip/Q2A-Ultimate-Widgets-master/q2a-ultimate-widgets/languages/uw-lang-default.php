<?php

return array(
	'first_name' => 'Your Name',
	'last_name' => 'Last Name',
	'email' => 'E-Mail Address',
	'subscribe' => 'Subscribe',
	'invalid' => 'Invalid Email Address!',
	'subscribing' => 'Subscribing you now...',
	'subscribe_success' => 'Thanks for subscribing!',
	'subscribe_fail' => 'Mail Subscribtion was unsuccessful!',

	'stat_q' => 'Questions',
	'stat_a' => 'Answers',
	'stat_c' => 'Comments',

	'search' => 'Search',

	'ask' => 'Ask',

	'an' => 'A-',
	'an' => 'A-',
	'ap' => 'A+',
	'reset' => 'Reset',
	'night_mode' => 'Night Mode',
);
