<p style="width: 100%; display: inline-block; text-align: center;">
	<a href="http://qa-themes.com/">
		<img src="http://qa-themes.com/files/q2a-theme-logo.png" alt="Question2Answer Themes" style="text-align: center;">
	</a>
</p>
<p style="font-size: 115%;">
<strong><a href="http://qa-themes.com/plugins/q2a-ultimate-seo">Question2Answer Ultimate Widgets</a></strong> is developed and maintained by <a href="http://qa-themes.com">QA-Themes.com</a>.
for more Q2A freebies and tutorials you can checkout our <a href="http://qa-themes.com/themes">Q2A Themes</a> and <a href="http://qa-themes.com/plugins">Plugins</a>.
</p>
<hr>
<p style="font-size: 115%;">Hi There!</p>
<p style="font-size: 115%;">
This is  <a href="http://towhidn.com">Towhid</a>. the developer behind Q2A Ultimate SEO. please feel free to say hello to me on <a href="https://twitter.com/towhidn">Twitter</a>, <a href="https://www.facebook.com/pages/Towhid-Nategheian/326504900812131">FaceBook</a>, and <a href="https://plus.google.com/+Towhidn">Google+</a>.
</p>
<p style="font-size: 115%;">
Also if you need professional Q2A development, I might just be the guy you were looking for.
</p>
