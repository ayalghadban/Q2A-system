simple-social-sharing
=====================

A simple, bloat-free social sharing plugin for Question2Answer platform
