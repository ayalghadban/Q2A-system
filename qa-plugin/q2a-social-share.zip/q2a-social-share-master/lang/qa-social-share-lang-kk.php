<?php
    return array(
        'sss_settings_saved'               => 'Бөлісу баптауы сәтті сақталды',
        'enter_share_text_for_home'        => 'Бас беттің мәтіні:',
        'enter_share_text'                 => 'Сұрақ бетінің мәтіні :',
        'choose_buttons_from_below'        => '<br />Бөлісу батырмасын таңдаңыз: ',
        'fb'                               => 'Facebook',
        'gp'                               => 'Google+',
        'li'                               => 'LinkedIn',
        'tw'                               => 'Twitter',
        'reddit'                           => 'Reddit',
        're'                               => 'Reddit',
        'em'                               => 'Mail.ru',
        'vk'                               => 'Vk.com',
        'email'                            => 'Email',
        'sharing_btn_enable_note'          => '<br />Виджет үшін төмендегі батырмаларды қолдансаңыз болады',
        'currently_enabled'                => 'Қазір қосулы <em>(Өшіруіңізге болады)</em>',
        'currently_disabled'               => 'Қазір өшірулі <em>(Қосуыңызға болады)</em>',
        'save_changes'                     => 'Баптау сақталды ',
        'custom_css'                       => 'Өзіңіздің css енгізіңіз',
        'default_share_text'               => 'Бөлісу қосулы ',
        'choose_share_type'                => 'Бөлісу түрін таңдаңыз ',
        'or'                               => 'немесе ',
        /*share types options */
        'image_icons'                      => 'Сурет иконмен ',
        'textual_share'                    => 'Мәтінді бөлісу',
        'colored_btns'                     => "Бөлісу батырмасы түспен ",
        'colored_btns_with_icon'           => "Бөлісу батырмасы түспен және икон",
        'font_icons_squared'               => "Font Icons домалақ",
        'font_icons_squared_shadowed'      => "Font Icons домалақ Shadowed ",
        'font_icons_semi_rounded'          => "Font Icons домалақ Semi Rounded ",
        'font_icons_semi_rounded_shadowed' => "Font Icons домалақ Semi Rounded Shadowed ",
        'font_icons_rounded'               => "Font Icons домалақ Rounded  ",
        'font_icons_rounded_shadowed'      => "Font Icons домалақ Rounded Shadowed",
    );

    /*
        Omit PHP closing tag to help avoid accidental output
    */